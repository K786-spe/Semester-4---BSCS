﻿#include "CircularLinkedList.h"

// Declare global function
void reverseKvalues(CircularLinkedList* list, int pos, int k);

int main() {
    CircularLinkedList list;

    // Example 1: A → B → C → D → E, pos=2, k=3
    cout << "Example 1:" << endl;
    list.insertAtLast('A');
    list.insertAtLast('B');
    list.insertAtLast('C');
    list.insertAtLast('D');
    list.insertAtLast('E');
    cout << "Original list: ";
    list.display();

    reverseKvalues(&list, 2, 3);
    cout << "Updated list: ";
    list.display();

    // Reset list for Example 2
    CircularLinkedList list2;
    cout << "\nExample 2:" << endl;
    list2.insertAtLast('A');
    list2.insertAtLast('B');
    list2.insertAtLast('C');
    list2.insertAtLast('D');
    list2.insertAtLast('E');
    cout << "Original list: ";
    list2.display();

    reverseKvalues(&list2, 3, 4);
    cout << "Updated list: ";
    list2.display();

    return 0;
}
