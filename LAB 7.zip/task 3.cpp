#include "myLinkedList.h"

int main() {
    myLinkedList list;

    cout << "Inserting values: 40, 10, 30, 20" << endl;
    list.insertAtLast(40);
    list.insertAtLast(10);
    list.insertAtLast(30);
    list.insertAtLast(20);
    list.display();

    cout << "Swapping positions 2 and 4" << endl;
    list.swap(2, 4);
    list.display();

    cout << "Sorting in ascending order" << endl;
    list.sort(true);
    list.display();

    cout << "Sorting in descending order" << endl;
    list.sort(false);
    list.display();

    return 0;
}
