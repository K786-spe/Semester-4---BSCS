#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node(int val = 0) {
        data = val;
        next = nullptr;
    }
};

class LinkedList {
protected:
    Node* first;
    Node* last;
public:
    LinkedList() { first = nullptr; last = nullptr; }

    // Copy Constructor (Deep Copy)
    LinkedList(const LinkedList& other) {
        first = nullptr;
        last = nullptr;
        Node* temp = other.first;
        while (temp != nullptr) {
            insertAtLast(temp->data);
            temp = temp->next;
        }
    }

    // Destructor
    virtual ~LinkedList() {
        Node* temp = first;
        while (temp != nullptr) {
            Node* nextNode = temp->next;
            delete temp;
            temp = nextNode;
        }
        first = nullptr;
        last = nullptr;
    }

    // Pure virtual functions
    virtual void insertAtLast(int) = 0;
    virtual void insertAtFirst(int) = 0;
    virtual int removeFromFirst() = 0;
    virtual int removeFromLast() = 0;
    virtual bool isEmpty() = 0;
    virtual void display() = 0;
};

#endif
