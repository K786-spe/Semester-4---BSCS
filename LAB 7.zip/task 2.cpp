#include "updated_myLinkedList.h"

int main() {
    myLinkedList list;

    cout << "Inserting values: 10, 20, 30, 40" << endl;
    list.insertAtLast(10);
    list.insertAtLast(20);
    list.insertAtLast(30);
    list.insertAtLast(40);
    list.display();

    cout << "Size of list: " << list.getSize() << endl;

    cout << "Searching for 20: " << (list.search(20) ? "Found" : "Not Found") << endl;
    cout << "Searching for 50: " << (list.search(50) ? "Found" : "Not Found") << endl;

    cout << "Peek at position 2: " << list.peek(2) << endl;
    cout << "Peek at position 5: " << list.peek(5) << endl;

    cout << "Get (remove) value at position 3: " << list.get(3) << endl;
    list.display();

    cout << "Get (remove) value at position 1: " << list.get(1) << endl;
    list.display();

    return 0;
}
