#include "myLinkedList.h"

// Global function to reverse k values from position pos
void reverseKvalues (myLinkedList& list, int pos, int k) {
    if (list.isEmpty() || k <= 1) return;

    int size = list.getSize();
    if (pos <= 0 || pos > size || pos + k - 1 > size) {
        cout << "Invalid position or k value!" << endl;
        return;
    }

    // Step 1: Traverse to pos
    Node* startPrev = nullptr;
    Node* start = list.first;
    for (int i = 1; i < pos; i++) {
        startPrev = start;
        start = start->next;
    }

    // Step 2: Reverse k nodes
    Node* prev = nullptr;
    Node* curr = start;
    Node* next = nullptr;
    for (int i = 0; i < k; i++) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }

    // Step 3: Connect reversed part back
    if (startPrev != nullptr) {
        startPrev->next = prev;
    }
    else {
        list.first = prev; // reversed from head
    }
    start->next = curr;

    // Step 4: Update last pointer if needed
    if (curr == nullptr) {
        list.last = start;
    }
}



#include "myLinkedList.h"

// Declare global function
void reverseKvalues(myLinkedList& list, int pos, int k);

int main() {
    myLinkedList list;

    // Example 1: A ? B ? C ? D ? E, pos=2, k=3
    cout << "Example 1:" << endl;
    list.insertAtLast('A');
    list.insertAtLast('B');
    list.insertAtLast('C');
    list.insertAtLast('D');
    list.insertAtLast('E');
    cout << "Original list: ";
    list.display();

    reverseKvalues(list, 2, 3);
    cout << "Updated list: ";
    list.display();

    // Reset list for Example 2
    myLinkedList list2;
    cout << "\nExample 2:" << endl;
    list2.insertAtLast('A');
    list2.insertAtLast('B');
    list2.insertAtLast('C');
    list2.insertAtLast('D');
    list2.insertAtLast('E');
    cout << "Original list: ";
    list2.display();

    reverseKvalues(list2, 1, 4);
    cout << "Updated list: ";
    list2.display();

    return 0;
}
