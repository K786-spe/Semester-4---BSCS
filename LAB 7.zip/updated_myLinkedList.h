#ifndef MYLINKEDLIST_H
#define MYLINKEDLIST_H

#include "updated_LinkedList.h"

class myLinkedList : public LinkedList {
public:
    myLinkedList() : LinkedList() {}

    // Copy Constructor (Deep Copy)
    myLinkedList(const myLinkedList& other) : LinkedList(other) {}

    // Destructor
    ~myLinkedList() {}

    void insertAtLast(int value) override {
        Node* nn = new Node(value);
        if (first == nullptr && last == nullptr) {
            first = nn;
            last = nn;
        }
        else {
            last->next = nn;
            last = nn;
        }
    }

    void insertAtFirst(int value) override {
        Node* nn = new Node(value);
        if (first == nullptr && last == nullptr) {
            first = nn;
            last = nn;
        }
        else {
            nn->next = first;
            first = nn;
        }
    }

    int removeFromFirst() override {
        if (isEmpty()) {
            cout << "LL is empty; returning NULL value" << endl;
            return -99999;
        }
        int returningValue = first->data;
        Node* temp = first;
        if (first == last) {
            first = nullptr;
            last = nullptr;
        }
        else {
            first = first->next;
        }
        delete temp;
        return returningValue;
    }

    int removeFromLast() override {
        if (isEmpty()) {
            cout << "LL is empty; returning NULL value" << endl;
            return -99999;
        }
        int returningValue = last->data;
        if (first == last) {
            delete last;
            first = nullptr;
            last = nullptr;
        }
        else {
            Node* temp = first;
            while (temp->next != last) {
                temp = temp->next;
            }
            delete last;
            last = temp;
            last->next = nullptr;
        }
        return returningValue;
    }

    bool isEmpty() override {
        return first == nullptr && last == nullptr;
    }

    void display() override {
        if (isEmpty()) {
            cout << "->" << endl;
            return;
        }
        Node* temp = first;
        while (temp != nullptr) {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }

    // ----------- Task 2 Functions -----------
    int getSize() {
        int count = 0;
        Node* temp = first;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        return count;
    }

    bool search(int v) {
        Node* temp = first;
        while (temp != nullptr) {
            if (temp->data == v) return true;
            temp = temp->next;
        }
        return false;
    }

    int peek(int pos) {
        if (pos <= 0) {
            cout << "Invalid position!" << endl;
            return -99999;
        }
        Node* temp = first;
        int index = 1;
        while (temp != nullptr) {
            if (index == pos) return temp->data;
            temp = temp->next;
            index++;
        }
        cout << "Position out of range!" << endl;
        return -99999;
    }

    int get(int pos) {
        if (pos <= 0) {
            cout << "Invalid position!" << endl;
            return -99999;
        }
        if (isEmpty()) {
            cout << "List is empty!" << endl;
            return -99999;
        }
        if (pos == 1) {
            return removeFromFirst();
        }
        Node* temp = first;
        Node* prev = nullptr;
        int index = 1;
        while (temp != nullptr) {
            if (index == pos) {
                int val = temp->data;
                prev->next = temp->next;
                if (temp == last) last = prev;
                delete temp;
                return val;
            }
            prev = temp;
            temp = temp->next;
            index++;
        }
        cout << "Position out of range!" << endl;
        return -99999;
    }

    // ----------- Task 3 Functions -----------

    void swap(int xi, int yi) {
        if (xi <= 0 || yi <= 0) {
            cout << "Invalid positions!" << endl;
            return;
        }
        if (xi == yi) return; // nothing to swap

        Node* nodeX = nullptr;
        Node* nodeY = nullptr;
        Node* temp = first;
        int index = 1;
        while (temp != nullptr) {
            if (index == xi) nodeX = temp;
            if (index == yi) nodeY = temp;
            temp = temp->next;
            index++;
        }
        if (nodeX && nodeY) {
            int t = nodeX->data;
            nodeX->data = nodeY->data;
            nodeY->data = t;
        }
        else {
            cout << "Position(s) out of range!" << endl;
        }
    }

    void sort(bool asc) {
        if (isEmpty() || first == last) return; // 0 or 1 element

        for (Node* i = first; i != nullptr; i = i->next) {
            for (Node* j = i->next; j != nullptr; j = j->next) {
                if (asc) {
                    if (i->data > j->data) {
                        int t = i->data;
                        i->data = j->data;
                        j->data = t;
                    }
                }
                else {
                    if (i->data < j->data) {
                        int t = i->data;
                        i->data = j->data;
                        j->data = t;
                    }
                }
            }
        }
    }
};

#endif
