#pragma once

#ifndef CIRCULARLINKEDLIST_H
#define CIRCULARLINKEDLIST_H

#include <iostream>
using namespace std;

class Node {
public:
    char data;
    Node* next;
    Node(char val = 0) {
        data = val;
        next = nullptr;
    }
};

class CircularLinkedList {
public:
    Node* last;

    CircularLinkedList() { last = nullptr; }

    void insertAtLast(char value) {
        Node* nn = new Node(value);
        if (last == nullptr) {
            last = nn;
            last->next = last; // circular
        }
        else {
            nn->next = last->next;
            last->next = nn;
            last = nn;
        }
    }

    void display() {
        if (last == nullptr) {
            cout << "->" << endl;
            return;
        }
        Node* temp = last->next;
        do {
            cout << temp->data << " -> ";
            temp = temp->next;
        } while (temp != last->next);
        cout << "(back to head)" << endl;
    }

    int getSize() {
        if (last == nullptr) return 0;
        int count = 0;
        Node* temp = last->next;
        do {
            count++;
            temp = temp->next;
        } while (temp != last->next);
        return count;
    }
};

#endif


// Reverse k values from position pos in CircularLinkedList
void reverseKvalues(CircularLinkedList* list, int pos, int k) {
    if (list->last == nullptr || k <= 1) return;

    int size = list->getSize();
    if (pos <= 0 || pos > size || pos + k - 1 > size) {
        cout << "Invalid position or k value!" << endl;
        return;
    }

    // Step 1: Traverse to pos
    Node* startPrev = list->last;
    Node* start = list->last->next;
    for (int i = 1; i < pos; i++) {
        startPrev = start;
        start = start->next;
    }

    // Step 2: Reverse k nodes
    Node* prev = nullptr;
    Node* curr = start;
    Node* next = nullptr;
    for (int i = 0; i < k; i++) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }

    // Step 3: Connect reversed part back
    startPrev->next = prev;
    start->next = curr;

    // Step 4: Update last if needed
    if (curr == list->last->next) {
        list->last = start;
    }
}
