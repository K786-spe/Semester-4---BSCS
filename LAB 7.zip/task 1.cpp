#include "updated_myLinkedList.h"
#include <iostream>
using namespace std;

int main() {
    myLinkedList list;

    cout << "Inserting at last: 10, 20, 30" << endl;
    list.insertAtLast(10);
    list.insertAtLast(20);
    list.insertAtLast(30);
    list.display();

    cout << "Inserting at first: 5" << endl;
    list.insertAtFirst(5);
    list.display();

    cout << "Removing from first: " << list.removeFromFirst() << endl;
    list.display();

    cout << "Removing from last: " << list.removeFromLast() << endl;
    list.display();

    cout << "Testing Copy Constructor" << endl;
    myLinkedList copiedList(list);
    copiedList.display();

    return 0;
}
