/*
Step 1: This task adds insert, shiftRight, shiftLeft functions to queues.
Step 2: I will insert values at given positions by dequeuing into a temp queue and re-enqueuing. For shifting, I will move values right or left.
Step 3: I will reuse enqueue, dequeue, append from Task 1.
Step 4: I learned how to manipulate positions inside queues.
Step 5: I developed skills for positional operations in queues.
*/

#include <iostream>
using namespace std;
#include "Stack.h"
#include "MyStack.h"
#include "Queue.h"
#include "MyQueue.h"

// Reuse display, append, reverseAppend, getSize from Task 1

void insert(Queue* q, int v, int pos) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    MyQueue result(temp.isEmpty() ? 0 : 10);
    int count = 0;
    while (!temp.isEmpty()) {
        if (count == pos) result.enqueue(v);
        result.enqueue(temp.dequeue());
        count++;
    }
    *dynamic_cast<MyQueue*>(q) = result;
}
void shiftRight(Queue* q, int pos) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    int size = 0; while (!temp.isEmpty()) { temp.dequeue(); size++; }
    if (pos < size) {
        int last = dynamic_cast<MyQueue*>(q)->dequeue();
        dynamic_cast<MyQueue*>(q)->enqueue(last);
    }
}
void shiftLeft(Queue* q, int pos) {
    if (!q->isEmpty()) {
        int first = q->dequeue();
        q->enqueue(first);
    }
}

const int MAX_SIZE = 10;
int main() {
    Queue* A = new MyQueue(MAX_SIZE);
    A->enqueue(10); A->enqueue(9); A->enqueue(2); A->enqueue(5); A->enqueue(-7);
    cout << "Queue A Values: "; A->display(cout);

    Queue* B = new MyQueue(MAX_SIZE);
    insert(B, -100, 2);
    cout << "Queue B Values after insert: "; B->display(cout);

    insert(A, B, 2);
    cout << "Queue B Values after insert: "; B->display(cout);

    shiftRight(B, 2);
    cout << "Queue B Values after shiftRight from pos 2: "; B->display(cout);

    shiftLeft(B, 2);
    cout << "Queue B Values after shiftLeft from pos 2: "; B->display(cout);

    return 0;
}
