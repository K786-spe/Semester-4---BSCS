/*
Step 1: This task is about reversing the first K elements of a queue. The rest of the queue remains unchanged.
Step 2: I will use a stack to reverse the first K elements because stack works in LIFO order. Steps:
        - Dequeue first K elements from the queue and push them into the stack.
        - Pop all elements from the stack and enqueue back into the queue (this reverses them).
        - Finally, move the remaining elements (size - K) from front to rear to preserve order.
Step 3: I will reuse enqueue, dequeue, isEmpty, isFull functions. Stack is necessary here because queue alone cannot reverse order.
Step 4: I learned how stack and queue can be combined to solve problems.
Step 5: I developed skills in combining ADTs for practical problems like reversing parts of sequences.
*/

#include <iostream>
using namespace std;
#include "Stack.h"
#include "MyStack.h"
#include "Queue.h"
#include "MyQueue.h"

void reverseFirstKElements(Queue* q, int k) {
    MyStack st(k);
    // Step 1: Dequeue first K elements into stack
    for (int i = 0; i < k; i++) {
        int val = q->dequeue();
        st.push(val);
    }
    // Step 2: Pop from stack back into queue
    int v;
    while (st.pop(v)) {
        q->enqueue(v);
    }
    // Step 3: Move remaining elements to back
    int size = 0;
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    while (!temp.isEmpty()) { temp.dequeue(); size++; }
    for (int i = 0; i < size - k; i++) {
        int val = q->dequeue();
        q->enqueue(val);
    }
}

const int MAX_SIZE = 10;
int main() {
    Queue* q = new MyQueue(MAX_SIZE);
    q->enqueue(10); q->enqueue(20); q->enqueue(30); q->enqueue(40); q->enqueue(50);

    cout << "Original Queue: "; q->display(cout);
    reverseFirstKElements(q, 3);
    cout << "Queue after reversing first 3 elements: "; q->display(cout);

    Queue* q2 = new MyQueue(MAX_SIZE);
    q2->enqueue(15); q2->enqueue(0); q2->enqueue(-3); q2->enqueue(99);
    cout << "Original Queue: "; q2->display(cout);
    reverseFirstKElements(q2, 4);
    cout << "Queue after reversing first 4 elements: "; q2->display(cout);

    return 0;
}
