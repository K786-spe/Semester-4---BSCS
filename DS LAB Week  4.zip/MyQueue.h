#pragma once

#include "Queue.h"

class MyQueue : public Queue {
public:
    MyQueue(int s) : Queue(s) {
        if (s != 0) {
            values = new int[maxCapacity] {0};
        }
    }
    MyQueue(const MyQueue& mq) : Queue(mq) {
        if (maxCapacity != 0 || values == nullptr) {
            values = new int[maxCapacity] {0};
            for (int i = 0; i < count; i++) {
                values[i] = mq.values[i];
            }
        }
    }
    ~MyQueue() {
        if (values != nullptr) {
            delete[] values;
            values = nullptr;
        }
    }
    void enqueue(const int& value);
    int dequeue();
    void display(ostream&) const;
};

void MyQueue::enqueue(const int& value) {
    if (!isFull()) {
        if (startOfQIndex == -1) startOfQIndex = 0;
        values[++topOfQIndex] = value;
        count++;
    }
    else {
        cout << "Queue is full\n";
    }
}

int MyQueue::dequeue() {
    if (!isEmpty()) {
        int val = values[startOfQIndex++];
        count--;
        return val;
    }
    cout << "Queue is empty\n";
    return -1;
}

void MyQueue::display(ostream& out) const {
    if (isEmpty()) {
        out << "Queue is empty\n";
        return;
    }
    for (int i = startOfQIndex; i <= topOfQIndex; i++) {
        out << values[i] << " ";
    }
    out << endl;
}


