/*
Step 1: This task is about basic queue functions like read, display, append, reverseAppend, stats, and isEqual.
Step 2: I will use enqueue and dequeue to manipulate queues. For example, append(A,B) means values from A are enqueued into B. Queue progression: (10 -> 20 -> 30 ->).
Step 3: I will reuse enqueue, dequeue, isEmpty, isFull functions. For reverseAppend, I will use a stack to reverse order.
Step 4: I learned how queues maintain FIFO order and how stacks can help reverse.
Step 5: I developed skills in queue manipulation, useful for problems like scheduling, buffering, and order management.
*/

#include <iostream>
using namespace std;
#include "Stack.h"
#include "MyStack.h"
#include "Queue.h"
#include "MyQueue.h"

// Functions
void read(Queue* q, istream& in) {
    int val;
    while (!q->isFull() && in >> val) {
        q->enqueue(val);
    }
}
void display(Queue* q, ostream& out) { q->display(out); }
void append(Queue* src, Queue* dst) {
    MyQueue temp(*dynamic_cast<MyQueue*>(src));
    while (!temp.isEmpty()) dst->enqueue(temp.dequeue());
}
void append(Queue* src, Queue* dst, int no) {
    MyQueue temp(*dynamic_cast<MyQueue*>(src));
    for (int i = 0; i < no && !temp.isEmpty(); i++) dst->enqueue(temp.dequeue());
}
void reverseAppend(Queue* src, Queue* dst) {
    MyQueue temp(*dynamic_cast<MyQueue*>(src));
    MyStack st(temp.isEmpty() ? 0 : 5);
    while (!temp.isEmpty()) st.push(temp.dequeue());
    int v; while (st.pop(v)) dst->enqueue(v);
}
int getSize(Queue* q) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    int count = 0; while (!temp.isEmpty()) { temp.dequeue(); count++; }
    return count;
}
void stats(Queue* q, int& sum, float& average) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    sum = 0; int count = 0;
    while (!temp.isEmpty()) { int v = temp.dequeue(); sum += v; count++; }
    average = (count > 0) ? (float)sum / count : 0;
}
bool isEqual(Queue* q1, Queue* q2) {
    MyQueue t1(*dynamic_cast<MyQueue*>(q1)), t2(*dynamic_cast<MyQueue*>(q2));
    while (!t1.isEmpty() && !t2.isEmpty()) if (t1.dequeue() != t2.dequeue()) return false;
    return t1.isEmpty() && t2.isEmpty();
}

const int MAX_SIZE = 5;
int main() {
    Queue* A = new MyQueue(MAX_SIZE);
    read(A, cin);
    cout << "Queue A Values: "; display(A, cout);

    Queue* B = new MyQueue(MAX_SIZE);
    append(A, B);
    cout << "Queue B Values: "; display(B, cout);

    Queue* C = new MyQueue(MAX_SIZE);
    C->enqueue(9); C->enqueue(7); C->enqueue(5);
    append(A, C, 2);
    cout << "Queue C Values after append of 2 values from A: "; display(C, cout);

    Queue* D = new MyQueue(MAX_SIZE);
    reverseAppend(C, D);
    cout << "Queue D Values after reverse append from C: "; display(D, cout);

    int sum = 0; float avg = 0;
    stats(A, sum, avg);
    cout << "Queue A Values: "; display(A, cout);
    cout << "Average is " << avg << " sum is " << sum << endl;

    return 0;
}
