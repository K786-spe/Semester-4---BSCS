/*
Step 1: This task adds get, sort, palindrome check, rotateLeft, rotateRight.
Step 2: I will use queue traversal and stack for palindrome. Sorting will be done by repeatedly finding min.
Step 3: I will reuse insert, append, shift functions.
Step 4: I learned how to check palindrome and sort queues.
Step 5: I developed skills for advanced queue operations.
*/

#include <iostream>
using namespace std;
#include "Stack.h"
#include "MyStack.h"
#include "Queue.h"
#include "MyQueue.h"

int get(Queue* q, int pos) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    int count = 0, val = -1;
    while (!temp.isEmpty()) {
        int v = temp.dequeue();
        if (count == pos) { val = v; break; }
        count++;
    }
    return val;
}
void sort(Queue* q) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    int arr[20], n = 0;
    while (!temp.isEmpty()) arr[n++] = temp.dequeue();
    for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (arr[i] > arr[j]) swap(arr[i], arr[j]);
    for (int i = 0; i < n; i++) q->enqueue(arr[i]);
}
bool isPalindrome(Queue* q) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    int arr[20], n = 0;
    while (!temp.isEmpty()) arr[n++] = temp.dequeue();
    for (int i = 0; i < n / 2; i++) if (arr[i] != arr[n - 1 - i]) return false;
    return true;
}
void rotateLeft(Queue* q, int pos) {
    for (int i = 0; i < pos; i++) { int v = q->dequeue(); q->enqueue(v); }
}
void rotateRight(Queue* q, int pos) {
    MyQueue temp(*dynamic_cast<MyQueue*>(q));
    int arr[20], n = 0;
    while (!temp.isEmpty()) arr[n++] = temp.dequeue();
    for (int i = 0; i < n; i++) q->enqueue(arr[(i - pos + n) % n]);
}

const int MAX_SIZE = 10;
int main() {
    Queue* A = new MyQueue(MAX_SIZE);
    A->enqueue(10); A->enqueue(9); A->enqueue(2); A->enqueue(5); A->enqueue(-7);
    cout << "Queue A Values: "; A->display(cout);

    rotateRight(A, 2);
    cout << "Queue A after rotateRight: "; A->display(cout);

    rotateLeft(A, 2);
    cout << "Queue A after rotateLeft: "; A->display(cout);

    int v = get(A, 3);
    cout << "Value at pos 3: " << v << endl;

    if (isPalindrome(A)) cout << "A is Palindrome\n"; else