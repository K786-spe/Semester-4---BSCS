/*
Step 1: This task simulates a fast food restaurant order system using queues. Orders must be served in the same sequence they are placed.
Step 2: I will create an Order class with item, price, and time. I will enqueue orders as customers place them. The cook dequeues orders, prepares them, and then they are served.
Step 3: I will reuse enqueue, dequeue, display functions. Queue is necessary because it ensures FIFO order.
Step 4: I learned how queues can model real-world systems like order management.
Step 5: I developed skills in applying ADTs to practical problems like restaurant order handling.
*/

#include <iostream>
#include <string>
using namespace std;
#include "Stack.h"
#include "MyStack.h"
#include "Queue.h"
#include "MyQueue.h"

class Order {
public:
    string item;
    int price;
    int timeTaken;
    Order(string i = "", int p = 0, int t = 0) : item(i), price(p), timeTaken(t) {}
};

class OrderQueue : public MyQueue {
public:
    OrderQueue(int s) : MyQueue(s) {}
    void enqueueOrder(Order o) {
        // For simplicity, store price as int in queue
        enqueue(o.price);
        cout << "Order placed: " << o.item << " Price: " << o.price << " Time: " << o.timeTaken << " minutes\n";
    }
    void serveOrder(Order o) {
        int val = dequeue();
        cout << "Order served: " << o.item << " Price: " << val << " Time: " << o.timeTaken << " minutes\n";
    }
};

const int MAX_SIZE = 20;
int main() {
    OrderQueue orders(MAX_SIZE);

    // Example menu
    Order burger("Burger", 200, 20);
    Order sandwich("Sandwich", 250, 30);
    Order fries("French Fries", 100, 10);
    Order chicken("Fried Chicken", 400, 40);
    Order pizza("Pizza", 350, 40);

    // Place orders
    orders.enqueueOrder(burger);
    orders.enqueueOrder(sandwich);
    orders.enqueueOrder(fries);

    // Serve orders in sequence
    orders.serveOrder(burger);
    orders.serveOrder(sandwich);
    orders.serveOrder(fries);

    // Calculate earnings
    int total = burger.price + sandwich.price + fries.price;
    cout << "Total money earned: " << total << endl;

    return 0;
}
