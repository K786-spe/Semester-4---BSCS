//#include <iostream>
//using namespace std;
//
//template <typename T>
//class AbstractQueue {
//public:
//    virtual void enQueue(T value) = 0;
//    virtual T deQueue() = 0;
//    virtual T front() const = 0;
//    virtual bool isEmpty() const = 0;
//    virtual bool isFull() const = 0;
//    virtual ~AbstractQueue() {}
//};
//
//template <typename T>
//class myQueue : public AbstractQueue<T> {
//private:
//    T* arr;
//    int frontIndex, rearIndex, capacity, count;
//public:
//    myQueue(int size) {
//        capacity = size;
//        arr = new T[capacity];
//        frontIndex = 0;
//        rearIndex = -1;
//        count = 0;
//    }
//
//    void enQueue(T value) override {
//        if (isFull()) {
//            cout << "Queue is full!\n";
//            return;
//        }
//        rearIndex = (rearIndex + 1) % capacity;
//        arr[rearIndex] = value;
//        count++;
//    }
//
//    T deQueue() override {
//        if (isEmpty()) {
//            throw runtime_error("Queue is empty!");
//        }
//        T item = arr[frontIndex];
//        frontIndex = (frontIndex + 1) % capacity;
//        count--;
//        return item;
//    }
//
//    T front() const override {
//        if (isEmpty()) throw runtime_error("Queue is empty!");
//        return arr[frontIndex];
//    }
//
//    bool isEmpty() const override { return count == 0; }
//    bool isFull() const override { return count == capacity; }
//
//    void display() const {
//        if (isEmpty()) {
//            cout << "Queue is empty!\n";
//            return;
//        }
//        cout << "Queue elements: ";
//        for (int i = 0; i < count; i++) {
//            cout << arr[(frontIndex + i) % capacity] << " ";
//        }
//        cout << endl;
//    }
//
//    ~myQueue() { delete[] arr; }
//};
//
//int main() {
//    myQueue<int> q(5);
//    q.enQueue(10);
//    q.enQueue(20);
//    q.enQueue(30);
//    q.display();
//    cout << "Front: " << q.front() << endl;
//    cout << "Dequeued: " << q.deQueue() << endl;
//    q.display();
//}
