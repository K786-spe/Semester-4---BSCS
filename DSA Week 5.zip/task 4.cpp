#include <iostream>
using namespace std;

template <typename T>
class MyQueue {
private:
    T* arr;
    int frontIndex, rearIndex, count, capacity;

public:
    MyQueue(int size = 100) {
        capacity = size;
        arr = new T[capacity];
        frontIndex = 0;
        rearIndex = -1;
        count = 0;
    }

    void enqueue(T value) {
        if (count == capacity) {
            cout << "Queue is full! Cannot add ticket.\n";
            return;
        }
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = value;
        count++;
        cout << "Ticket " << value << " added.\n";
    }

    T dequeue() {
        if (isEmpty()) {
            throw runtime_error("No tickets to resolve!");
        }
        T item = arr[frontIndex];
        frontIndex = (frontIndex + 1) % capacity;
        count--;
        cout << "Ticket " << item << " resolved.\n";
        return item;
    }

    T front() const {
        if (isEmpty()) throw runtime_error("No tickets pending!");
        return arr[frontIndex];
    }

    bool isEmpty() const { return count == 0; }

    void display() const {
        if (isEmpty()) {
            cout << "No pending tickets.\n";
            return;
        }
        cout << "Pending tickets: ";
        for (int i = 0; i < count; i++) {
            cout << arr[(frontIndex + i) % capacity] << " ";
        }
        cout << endl;
    }

    ~MyQueue() { delete[] arr; }
};

// ------------------- Main -------------------
int main() {
    MyQueue<int> tickets(10);
    int choice, ticketID;

    do {
        cout << "\n--- Customer Support Ticket System ---\n";
        cout << "1. Add new ticket\n";
        cout << "2. Resolve ticket\n";
        cout << "3. Check next ticket\n";
        cout << "4. Display all tickets\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter 4-digit Ticket ID: ";
            cin >> ticketID;
            tickets.enqueue(ticketID);
            break;
        case 2:
            try {
                tickets.dequeue();
            }
            catch (runtime_error& e) {
                cout << e.what() << endl;
            }
            break;
        case 3:
            try {
                cout << "Next ticket: " << tickets.front() << endl;
            }
            catch (runtime_error& e) {
                cout << e.what() << endl;
            }
            break;
        case 4:
            tickets.display();
            break;
        case 5:
            cout << "Exiting system...\n";
            break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 5);

    return 0;
}
