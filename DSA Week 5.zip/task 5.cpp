#include <iostream>
#include <string>
using namespace std;

template <typename T>
class MyQueue {
private:
    T* arr;
    int frontIndex, rearIndex, count, capacity;

public:
    MyQueue(int size = 100) {
        capacity = size;
        arr = new T[capacity];
        frontIndex = 0;
        rearIndex = -1;
        count = 0;
    }

    void enqueue(T value) {
        if (count == capacity) {
            cout << "Print queue is full! Cannot add document.\n";
            return;
        }
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = value;
        count++;
        cout << "Document \"" << value << "\" added to print queue.\n";
    }

    T dequeue() {
        if (isEmpty()) {
            throw runtime_error("No documents to print!");
        }
        T item = arr[frontIndex];
        frontIndex = (frontIndex + 1) % capacity;
        count--;
        cout << "Printing document: " << item << endl;
        return item;
    }

    T front() const {
        if (isEmpty()) throw runtime_error("No documents pending!");
        return arr[frontIndex];
    }

    bool isEmpty() const { return count == 0; }

    void display() const {
        if (isEmpty()) {
            cout << "No pending print jobs.\n";
            return;
        }
        cout << "Pending print jobs: ";
        for (int i = 0; i < count; i++) {
            cout << arr[(frontIndex + i) % capacity] << " | ";
        }
        cout << endl;
    }

    ~MyQueue() { delete[] arr; }
};

// ------------------- Main -------------------
int main() {
    MyQueue<string> printQueue(10);
    int choice;
    string docName;

    do {
        cout << "\n--- Document Printing System ---\n";
        cout << "1. Add new document\n";
        cout << "2. Print document\n";
        cout << "3. Check next document\n";
        cout << "4. Display all documents\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter document name: ";
            cin.ignore(); // clear buffer
            getline(cin, docName);
            printQueue.enqueue(docName);
            break;
        case 2:
            try {
                printQueue.dequeue();
            }
            catch (runtime_error& e) {
                cout << e.what() << endl;
            }
            break;
        case 3:
            try {
                cout << "Next document: " << printQueue.front() << endl;
            }
            catch (runtime_error& e) {
                cout << e.what() << endl;
            }
            break;
        case 4:
            printQueue.display();
            break;
        case 5:
            cout << "Exiting system...\n";
            break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 5);

    return 0;
}
