//#include <iostream>
//using namespace std;
//
//// ------------------- Stack Template -------------------
//template <typename T>
//class MyStack {
//private:
//    T* arr;
//    int topIndex;
//    int capacity;
//
//public:
//    MyStack(int size = 100) {
//        capacity = size;
//        arr = new T[capacity];
//        topIndex = -1;
//    }
//
//    void push(T value) {
//        if (topIndex == capacity - 1) {
//            throw runtime_error("Stack overflow!");
//        }
//        arr[++topIndex] = value;
//    }
//
//    T pop() {
//        if (isEmpty()) {
//            throw runtime_error("Stack underflow!");
//        }
//        return arr[topIndex--];
//    }
//
//    T top() const {
//        if (isEmpty()) {
//            throw runtime_error("Stack is empty!");
//        }
//        return arr[topIndex];
//    }
//
//    bool isEmpty() const {
//        return topIndex == -1;
//    }
//
//    int size() const {
//        return topIndex + 1;
//    }
//
//    ~MyStack() {
//        delete[] arr;
//    }
//};
//
//
//template <typename T>
//class QueueUsingStacks {
//private:
//    MyStack<T> stack1;
//    MyStack<T> stack2;
//
//    void transfer() {
//        while (!stack1.isEmpty()) {
//            stack2.push(stack1.pop());
//        }
//    }
//
//public:
//    QueueUsingStacks(int size = 100) : stack1(size), stack2(size) {}
//
//    void enqueue(T value) {
//        stack1.push(value);
//        cout << value << " enqueued.\n";
//    }
//
//    T dequeue() {
//        if (stack2.isEmpty()) {
//            if (stack1.isEmpty()) {
//                throw runtime_error("Queue is empty!");
//            }
//            transfer();
//        }
//        return stack2.pop();
//    }
//
//    T front() {
//        if (stack2.isEmpty()) {
//            if (stack1.isEmpty()) {
//                throw runtime_error("Queue is empty!");
//            }
//            transfer();
//        }
//        return stack2.top();
//    }
//
//    bool isEmpty() {
//        return stack1.isEmpty() && stack2.isEmpty();
//    }
//
//    void display() {
//        if (isEmpty()) {
//            cout << "Queue is empty!\n";
//            return;
//        }
//
//        
//        MyStack<T> temp1 = stack1;
//        MyStack<T> temp2 = stack2;
//
//        cout << "Queue elements: ";
//
//        
//        MyStack<T> rev;
//        while (!temp2.isEmpty()) {
//            rev.push(temp2.pop());
//        }
//        while (!rev.isEmpty()) {
//            cout << rev.pop() << " ";
//        }
//
//        
//        MyStack<T> tempRev;
//        while (!temp1.isEmpty()) {
//            tempRev.push(temp1.pop());
//        }
//        while (!tempRev.isEmpty()) {
//            cout << tempRev.pop() << " ";
//        }
//
//        cout << endl;
//    }
//};
//
//
//int main() {
//    QueueUsingStacks<int> q(10);
//
//    q.enqueue(10);
//    q.enqueue(20);
//    q.enqueue(30);
//    q.display();
//
//    cout << "Front: " << q.front() << endl;
//    cout << "Dequeued: " << q.dequeue() << endl;
//    q.display();
//
//    q.enqueue(40);
//    q.enqueue(50);
//    q.display();
//
//    return 0;
//}
