#include <iostream>
#include <string>
using namespace std;

// ------------------- Package Struct -------------------
struct Package {
    int id;
    string address;
    int startTime;  // delivery window start
    int endTime;    // delivery window end
};

// ------------------- Queue Template -------------------
template <typename T>
class MyQueue {
private:
    T* arr;
    int frontIndex, rearIndex, count, capacity;

public:
    MyQueue(int size = 100) {
        capacity = size;
        arr = new T[capacity];
        frontIndex = 0;
        rearIndex = -1;
        count = 0;
    }

    void enqueue(T value) {
        if (count == capacity) {
            cout << "Queue is full! Cannot add package.\n";
            return;
        }
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = value;
        count++;
        cout << "Package " << value.id << " added.\n";
    }

    T dequeue() {
        if (isEmpty()) {
            throw runtime_error("No packages to deliver!");
        }
        T item = arr[frontIndex];
        frontIndex = (frontIndex + 1) % capacity;
        count--;
        cout << "Package " << item.id << " delivered.\n";
        return item;
    }

    T front() const {
        if (isEmpty()) throw runtime_error("No packages pending!");
        return arr[frontIndex];
    }

    bool isEmpty() const { return count == 0; }

    int size() const { return count; }

    void display() const {
        if (isEmpty()) {
            cout << "No pending packages.\n";
            return;
        }
        cout << "Pending packages:\n";
        for (int i = 0; i < count; i++) {
            T pkg = arr[(frontIndex + i) % capacity];
            cout << "ID: " << pkg.id
                << ", Address: " << pkg.address
                << ", Window: " << pkg.startTime << "-" << pkg.endTime << endl;
        }
    }

    ~MyQueue() { delete[] arr; }
};

// ------------------- Time Check Function -------------------
bool timeToDeliver(const Package& pkg, int currentTime) {
    return currentTime >= pkg.startTime && currentTime <= pkg.endTime;
}

// ------------------- Main -------------------
int main() {
    MyQueue<Package> deliveryQueue(10);
    int choice, id, start, end, currentTime;
    string address;

    do {
        cout << "\n--- Real-Time Package Delivery System ---\n";
        cout << "1. Add new package\n";
        cout << "2. Deliver package\n";
        cout << "3. Check next package\n";
        cout << "4. Display all packages\n";
        cout << "5. Check delivery time for front package\n";
        cout << "6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter Package ID: ";
            cin >> id;
            cout << "Enter Address: ";
            cin.ignore();
            getline(cin, address);
            cout << "Enter Start Time: ";
            cin >> start;
            cout << "Enter End Time: ";
            cin >> end;
            deliveryQueue.enqueue({ id, address, start, end });
            break;
        case 2:
            try {
                deliveryQueue.dequeue();
            }
            catch (runtime_error& e) {
                cout << e.what() << endl;
            }
            break;
        case 3:
            try {
                Package p = deliveryQueue.front();
                cout << "Next package -> ID: " << p.id
                    << ", Address: " << p.address
                    << ", Window: " << p.startTime << "-" << p.endTime << endl;
            }
            catch (runtime_error& e) {
                cout << e.what() << endl;
            }
            break;
        case 4:
            deliveryQueue.display();
            break;
        case 5:
            try {
                cout << "Enter current time: ";
                cin >> currentTime;
                Package p = deliveryQueue.front();
                if (timeToDeliver(p, currentTime)) {
                    cout << "Package " << p.id << " can be delivered on time.\n";
                }
                else {
                    cout << "Package " << p.id << " expired! Skipping...\n";
                    deliveryQueue.dequeue();
                }
            }
            catch (runtime_error& e) {
                cout << e.what() << endl;
            }
            break;
        case 6:
            cout << "Exiting system...\n";
            break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 6);

    return 0;
}
