#include <iostream>
using namespace std;


template <typename T>
class MyStack {
private:
    T* arr;
    int topIndex;
    int capacity;

public:
    MyStack(int size = 100) {
        capacity = size;
        arr = new T[capacity];
        topIndex = -1;
    }

    void push(T value) {
        if (topIndex == capacity - 1) throw runtime_error("Stack overflow!");
        arr[++topIndex] = value;
    }

    T pop() {
        if (isEmpty()) throw runtime_error("Stack underflow!");
        return arr[topIndex--];
    }

    bool isEmpty() const { return topIndex == -1; }
    int size() const { return topIndex + 1; }

    ~MyStack() { delete[] arr; }
};


template <typename T>
class MyQueue {
private:
    T* arr;
    int frontIndex, rearIndex, count, capacity;

public:
    MyQueue(int size = 100) {
        capacity = size;
        arr = new T[capacity];
        frontIndex = 0;
        rearIndex = -1;
        count = 0;
    }

    void enqueue(T value) {
        if (count == capacity) throw runtime_error("Queue full!");
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = value;
        count++;
    }

    T dequeue() {
        if (isEmpty()) throw runtime_error("Queue empty!");
        T item = arr[frontIndex];
        frontIndex = (frontIndex + 1) % capacity;
        count--;
        return item;
    }

    T front() const {
        if (isEmpty()) throw runtime_error("Queue empty!");
        return arr[frontIndex];
    }

    bool isEmpty() const { return count == 0; }
    int size() const { return count; }

    void display() const {
        if (isEmpty()) {
            cout << "Queue is empty!\n";
            return;
        }
        cout << "Queue: ";
        for (int i = 0; i < count; i++) {
            cout << arr[(frontIndex + i) % capacity] << " ";
        }
        cout << endl;
    }

    ~MyQueue() { delete[] arr; }
};


template <typename T>
void reverseFirstK(MyQueue<T>& q, int K) {
    if (K <= 0 || K > q.size()) return;

    MyStack<T> s(K);

    
    for (int i = 0; i < K; i++) {
        s.push(q.dequeue());
    }

    
    while (!s.isEmpty()) {
        q.enqueue(s.pop());
    }

    
    int remaining = q.size() - K;
    for (int i = 0; i < remaining; i++) {
        q.enqueue(q.dequeue());
    }
}


int main() {
    MyQueue<int> q(10);

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.enqueue(40);
    q.enqueue(50);

    cout << "Original ";
    q.display();

    int K = 3;
    reverseFirstK(q, K);

    cout << "After reversing first " << K << " elements: ";
    q.display();

    return 0;
}
