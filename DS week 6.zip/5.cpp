#include<iostream>
#include<string>

using namespace std;

class node {
public:
	string studentName;
	int priority;
	node* next;

	node(string name, int p) {
		studentName = name;
		priority = p;
		next = NULL;
	}

};

class linklist {
	node* head;
public:
	linklist() {
		head = NULL;
	}

	void addStudent(string name, int priority) {
		node* newnode = new node(name, priority);

		if (head == NULL || priority < head->priority) {
			newnode->next = head;
			head = newnode;
			return;
		}

		node* curr = head;
		while (curr->next != NULL && curr->next->priority <= priority) {
			curr = curr->next;

		}

		newnode->next = curr->next;
		curr->next = newnode;
	}



void removeStudent(string name) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    if (head->studentName == name) {
        node* temp = head;
        head = head->next;
        delete temp;
        cout << name << " removed from reservation list.\n";
        return;
    }

    node* curr = head;
    while (curr->next != NULL && curr->next->studentName != name) {
        curr = curr->next;
    }

    if (curr->next == NULL) {
        cout << "Student not found!\n";
        return;
    }

    node* temp = curr->next;
    curr->next = temp->next;
    delete temp;
    cout << name << " removed from reservation list.\n";
}


void updatePriority(string name, int newPriority) {
    removeStudent(name);
    addStudent(name, newPriority);
    cout << name << " priority updated to " << newPriority << endl;
}

void serveFront() {
    if (head == NULL) {
        cout << "No reservations!\n";
        return;
    }
    cout << head->studentName << " has received the book.\n";
    node* temp = head;
    head = head->next;
    delete temp;
}

int countStudents() {
    int count = 0;
    node* temp = head;
    while (temp != NULL) {
        count++;
        temp = temp->next;
    }
    return count;
}

void display() {
    if (head == NULL) {
        cout << "Reservation list is empty!\n";
        return;
    }

    node* temp = head;
    cout << "Reservation List: ";
    while (temp != NULL) {
        cout << "[" << temp->studentName << " (P" << temp->priority << ")] -> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}
};

int main() {
    linklist book1, book2;
    int choice, bookChoice, priority;
    string name;

    do {
        cout << "\n--- MENU ---\n";
        cout << "1. Add Student\n";
        cout << "2. Remove Student\n";
        cout << "3. Update Priority\n";
        cout << "4. Serve Front Student\n";
        cout << "5. Display Reservation List\n";
        cout << "6. Count Students\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 7) break;

        cout << "Select Book (1 or 2): ";
        cin >> bookChoice;
        linklist* selectedBook = (bookChoice == 1) ? &book1 : &book2;

        switch (choice) {
        case 1:
            cout << "Enter student name: ";
            cin >> name;
            cout << "Enter priority (1=Research, 2=Assignment, 3=Casual): ";
            cin >> priority;
            selectedBook->addStudent(name, priority);
            break;

        case 2:
            cout << "Enter student name to remove: ";
            cin >> name;
            selectedBook->removeStudent(name);
            break;

        case 3:
            cout << "Enter student name: ";
            cin >> name;
            cout << "Enter new priority: ";
            cin >> priority;
            selectedBook->updatePriority(name, priority);
            break;

        case 4:
            selectedBook->serveFront();
            break;

        case 5:
            selectedBook->display();
            break;

        case 6:
            cout << "Total students: " << selectedBook->countStudents() << endl;
            break;

        default:
            cout << "Invalid choice!" << endl;
        }

    } while (choice != 7);

    cout << "Exiting..." << endl;
    return 0;
}
