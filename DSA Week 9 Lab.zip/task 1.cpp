#include <iostream>
using namespace std;


class node {
public:
	node* left;
	node* right;
	int seat;
public:
	node(int data) {
		seat = data;
		right = NULL;
		left = NULL;
	}

};

class circularLL {
	node* tail;
public:
	circularLL() {
		tail = NULL;
	}
	void insert(int s) {
		node* newNode = new node(s);

		if (tail == NULL) {
			tail = newNode;
			tail->left = tail->right = tail;
		}
		else {
			node* head = tail->right;
			newNode->right = head;
			newNode->left = tail;

			tail->right = newNode;;
			head -> left = newNode;
			tail = newNode;

		}
	}
	void display() {
		if (tail == NULL) {
			cout << "No seats available.\n";
			return;
		}
		node* temp = tail->right;
		do {
			cout << temp->seat << " <-> ";
			temp = temp->right;
		} while (temp != tail->right);

	}
	void showNextTwo(int currentSeat) {
		if (tail == NULL)
			return;

		node* temp = tail->right;

		do {
			if (temp->seat == currentSeat) {

				cout << "Next seats: "
					<< temp->right->seat << ", "
					<< temp->right->right->seat << endl;

				return;
			}

			temp = temp->right;

		} while (temp != tail->right);

		cout << "Seat not found.\n";
	}
	void removeSeat(int seatNumber) {

		if (tail == NULL) return;

		node* curr = tail->right;

		do {
			if (curr->seat == seatNumber) {

				// Only one node
				if (curr == tail && curr->right == tail) {
					tail = NULL;
				}
				else {

					curr->left->right = curr->right;
					curr->right->left = curr->left;

					
					if (curr == tail) {
						tail = curr->left;
					}
				}

				delete curr;

				cout << seatNumber << " removed successfully.\n";
				return;
			}

			curr = curr->right;

		} while (curr != tail->right);

		cout << "Seat not found.\n";
	}

	void showNextOne(int currentSeat) {

		if (tail == NULL) return;

		node* temp = tail->right;

		do {
			if (temp->seat == currentSeat) {

				cout << "Next seat: "
					<< temp->right->seat << endl;

				return;
			}

			temp = temp->right;

		} while (temp != tail->right);

		cout << "Seat not found.\n";
	}
};





int main() {
	circularLL ride;

	ride.insert(1);
	ride.insert(2);
	ride.insert(3);
	ride.insert(4);
	ride.insert(5);

	cout << "Initial Seats:\n";
	ride.display();

	
	cout << "\nCurrent Front Seat: S3\n";
	ride.showNextTwo(3);


	cout << "\nClosing Seat S4...\n";
	ride.removeSeat(4);

	
	cout << "\nUpdated Seats:\n";
	ride.display();

	
	cout << "\nCurrent Front Seat: S3\n";
	ride.showNextOne(3);

	return 0;
}