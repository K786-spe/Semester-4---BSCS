#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string song;
    Node* next;
    Node* prev;

    Node(string s) {
        song = s;
        next = NULL;
        prev = NULL;
    }
};

class CircularPlaylist {

    Node* tail;

public:

    CircularPlaylist() {
        tail = NULL;
    }


    void insertSong(string s) {

        Node* newNode = new Node(s);

        // First node
        if (tail == NULL) {

            tail = newNode;
            tail->next = tail;
            tail->prev = tail;
        }
        else {

            Node* head = tail->next;

            newNode->next = head;
            newNode->prev = tail;

            tail->next = newNode;
            head->prev = newNode;

            tail = newNode;
        }
    }

   
    void displaySongs() {

        if (tail == NULL) {
            cout << "Playlist is empty.\n";
            return;
        }

        Node* head = tail->next;
        Node* temp = head;

        do {

            cout << temp->song;

            temp = temp->next;

            if (temp != head)
                cout << " -> ";

        } while (temp != head);

        cout << " -> (back to " << head->song << ")\n";
    }

    void showSongDetails(string currentSong) {

        if (tail == NULL) {
            cout << "Playlist is empty.\n";
            return;
        }

        Node* temp = tail->next;

        do {

            if (temp->song == currentSong) {

                cout << "\nCurrent: " << temp->song << endl;
                cout << "Previous: " << temp->prev->song << endl;
                cout << "Next: " << temp->next->song << endl;

                return;
            }

            temp = temp->next;

        } while (temp != tail->next);

        cout << "Song not found.\n";
    }
};

int main() {

    CircularPlaylist playlist;

    playlist.insertSong("Song1");
    playlist.insertSong("Song2");
    playlist.insertSong("Song3");
    playlist.insertSong("Song4");
    playlist.insertSong("Song5");

    cout << "Playlist:\n";
    playlist.displaySongs();

    string currentSong;

    cout << "\nEnter current song name: ";
    cin >> currentSong;

    playlist.showSongDetails(currentSong);

    return 0;
}