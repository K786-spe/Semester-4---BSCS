//
//#include <iostream>
//using namespace std;
//
//#include "Queue.h"
//#include "ArrayQueue.h"
//
//// ─── copyQueue: recursive ──────────────────────────────────────────────────
//// Base case: src empty → return
//// Recursive: dequeue from src, recurse, then enqueue → preserves order via call stack
//void copyQueue(ArrayQueue<int> src, ArrayQueue<int>& copy)
//{
//    if (src.isEmpty()) return;   // base case
//
//    int v = src.dequeue();       // take from front
//    copy.enqueue(v);             // enqueue BEFORE recursion → preserves front-to-back order
//
//    copyQueue(src, copy);        // recurse on rest
//}
//
//// ─── display: recursive ────────────────────────────────────────────────────
//// Base case: queue empty → return
//// Recursive: dequeue front, print it, then recurse (front-to-back order)
//void display(ArrayQueue<int> aq)
//{
//    if (aq.isEmpty()) return;    // base case
//
//    int v = aq.dequeue();        // take front element
//    cout << v << " ";            // print BEFORE recursion → front-to-back order
//    display(aq);                 // recurse on remaining
//}
//
//// ─── getSize: recursive ────────────────────────────────────────────────────
//// Base case: queue empty → return 0
//// Recursive: dequeue one, count it, add size of rest
//int getSize(ArrayQueue<int> aq)
//{
//    if (aq.isEmpty()) return 0;  // base case
//
//    aq.dequeue();                // remove one element
//    return 1 + getSize(aq);      // count it + size of the rest
//}
//
//// ─── max: recursive ─────────────────────────────────────────────────────────
//// Base case: only 1 element → dequeue and return it
//// Recursive: dequeue front, compare with max of rest
//int maxQueue(ArrayQueue<int> aq)
//{
//    int v = aq.dequeue();        // take front
//
//    if (aq.isEmpty()) return v;  // base case: only element
//
//    int restMax = maxQueue(aq);  // max of remaining
//
//    return (v > restMax) ? v : restMax;
//}
//
//// ─── helper: fill a queue ──────────────────────────────────────────────────
//ArrayQueue<int> makeQueue(int vals[], int n, int capacity)
//{
//    ArrayQueue<int> q(capacity);
//    for (int i = 0; i < n; i++) q.enqueue(vals[i]);
//    return q;
//}
//
//// ─── main ────────────────────────────────────────────────────────────────────
//int main()
//{
//    cout << "=== Task 4: Recursive ArrayQueue Functions ===" << endl << endl;
//
//    int data[] = {10, 40, 20, 70, 30};
//    ArrayQueue<int> original = makeQueue(data, 5, 10);
//
//    cout << "Original queue (front to back): ";
//    display(original);
//    cout << endl;
//
//    cout << "\n-- getSize: " << getSize(original) << " (expected 5) --" << endl;
//
//    cout << "-- maxQueue: " << maxQueue(original) << " (expected 70) --" << endl;
//
//    cout << "\n-- copyQueue test --" << endl;
//    ArrayQueue<int> copy(10);
//    copyQueue(original, copy);
//    cout << "Copy (front to back): ";
//    display(copy);
//    cout << endl;
//
//    cout << "\n-- Single element queue max --" << endl;
//    int single[] = {99};
//    ArrayQueue<int> q1 = makeQueue(single, 1, 5);
//    cout << "maxQueue([99]): " << maxQueue(q1) << " (expected 99)" << endl;
//
//    cout << "\n-- getSize on empty queue --" << endl;
//    ArrayQueue<int> empty(5);
//    cout << "getSize(empty): " << getSize(empty) << " (expected 0)" << endl;
//
//    cout << "\nDone." << endl;
//    return 0;
//}
