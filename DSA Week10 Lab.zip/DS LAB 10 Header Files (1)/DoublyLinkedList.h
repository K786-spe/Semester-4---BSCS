template <class T>
class DoublyLinkedList
{
public:
  DoublyLinkedList(){first = nullptr; last = nullptr;}
  DoublyLinkedList(const DoublyLinkedList & ll) {copyList(ll);}
  const DoublyLinkedList & operator = (const DoublyLinkedList & );
  virtual ~DoublyLinkedList(){deleteList();}
  virtual void insertAtLast(T) = 0;
  virtual void insertAtFirst(T) = 0;
  virtual T removeFromFirst() = 0;
  virtual T removeFromLast() = 0;
  virtual bool isEmpty() = 0;
  virtual void display() = 0;
protected:
  Node<T> *first;
  Node<T> *last;
  void deleteList();
  void copyList(const DoublyLinkedList<T>&);
};

template <class T>
const DoublyLinkedList<T> & DoublyLinkedList<T>::operator = (const DoublyLinkedList<T> & ll)
{
  if(this != & ll)
    {
      copyList(ll);
    }
  return *this;
}

