template <class T>
class ConcreteDoublyLinkedList:public DoublyLinkedList<T>
{
public:
  ConcreteDoublyLinkedList(): DoublyLinkedList<T>(){}
  ConcreteDoublyLinkedList(const ConcreteDoublyLinkedList<T>& mll) : DoublyLinkedList<T>(mll);
  const ConcreteDoublyLinkedList & operator = (const ConcreteDoublyLinkedList<T> & mll);
  void insertAtLast(T);
  void insertAtFirst(T);
  void display();
  T removeFromFirst();
  T removeFromLast();
  bool isEmpty();
};

template <class T>
const ConcreteDoublyLinkedList<T> & ConcreteDoublyLinkedList<T>::operator = (const ConcreteDoublyLinkedList<T> & dll)
{
  if(this != & dll)
    {
      DoublyLinkedList<T>::operator=(dll);
    }
  return *this;
}

