///*
//================================================================================
// task 1: doublylinkedlist class functions implementation
//================================================================================
//
//step 1 - understanding the task:
// the task requires implementing all the functions of the doublylinkedlist and
// concretedoublylinkedlist classes. a doublylinkedlist is a chain of nodes where
// each node holds data plus two pointers: one pointing to the next node (forward),
// and one pointing to the previous node (backward). the list keeps track of the
// first node and the last node. this allows traversal in both directions.
// we need to implement: insertatfirst, insertatlast, removefromfirst,
// removefromlast, isempty, display, deletelist, and copylist.
//
//step 2 - how i will do it:
// for insertatfirst:
//   - create a new node with the given data
//   - make new node's next = first (old first)
//   - make new node's previous = nullptr (it becomes the new front)
//   - if list was empty: last = new node
//   - else: old first's previous = new node
//   - set first = new node
//   visual: insert 10 at first in (20 <-> 30):
//     nullptr <- [10] <-> [20] <-> [30] -> nullptr
//
// for insertatlast:
//   - create a new node
//   - make new node's previous = last (old last)
//   - make new node's next = nullptr
//   - if list was empty: first = new node
//   - else: old last's next = new node
//   - set last = new node
//   visual: insert 40 at last in (10 <-> 20 <-> 30):
//     nullptr <- [10] <-> [20] <-> [30] <-> [40] -> nullptr
//
// for removefromfirst:
//   - save first node's data
//   - move first pointer forward: first = first->next
//   - if list is now empty: last = nullptr
//   - else: set new first's previous = nullptr
//   - delete old node
//   visual: remove from (10 <-> 20 <-> 30):
//     nullptr <- [20] <-> [30] -> nullptr  (returns 10)
//
// for removefromlast:
//   - save last node's data
//   - move last pointer backward: last = last->previous
//   - if list is now empty: first = nullptr
//   - else: set new last's next = nullptr
//   - delete old node
//
// for deletelist: traverse from first, keep deleting nodes one by one
// for copylist: traverse source list, call insertatlast for each element
//
//step 3 - functions reused:
// insertatlast is reused inside copylist — for each node in source list,
// we insert at last to preserve original order.
// isempty() is reused in removefromfirst and removefromlast to check safety.
//
// example after function calls:
//   start:          empty list
//   insertatlast(10): [10]
//   insertatlast(20): [10] <-> [20]
//   insertatlast(30): [10] <-> [20] <-> [30]
//   removefromfirst: [20] <-> [30]  (returned 10)
//   removefromlast:  [20]           (returned 30)
//
//step 4 - learning:
// i learned that a doubly linked list requires very careful pointer management.
// every time a node is inserted or removed, both the next and previous pointers
// of neighboring nodes must be updated. forgetting any pointer update causes
// broken links or memory errors.
//
//step 5 - skills developed:
// i can now implement bidirectional linked structures. i can manage dynamic
// memory with new/delete, and handle edge cases like empty lists and single-
// element lists. this skill applies to problems like browser history navigation,
// undo/redo systems, and implementing deques.
//================================================================================
//*/
//
//#include <iostream>
//using namespace std;
//
//
//
//template <class t>
//class node
//{
//public:
//    t data;
//    node* next;
//    node* previous;
//};
//template <class t>
//class doublylinkedlist
//{
//public:
//    doublylinkedlist() { first = nullptr; last = nullptr; }
//    doublylinkedlist(const doublylinkedlist& ll) { copylist(ll); }
//    const doublylinkedlist& operator = (const doublylinkedlist&);
//    virtual ~doublylinkedlist() { deletelist(); }
//    virtual void insertatlast(t) = 0;
//    virtual void insertatfirst(t) = 0;
//    virtual t removefromfirst() = 0;
//    virtual t removefromlast() = 0;
//    virtual bool isempty() = 0;
//    virtual void display() = 0;
//protected:
//    node<t>* first;
//    node<t>* last;
//    void deletelist();
//    void copylist(const doublylinkedlist*);
//};
//
//template <class t>
//const doublylinkedlist<t>& doublylinkedlist<t>::operator = (const doublylinkedlist<t>& ll)
//{
//    if (this != &ll)
//    {
//        copylist(ll);
//    }
//    return *this;
//}
//
//
//
//// ─── doublylinkedlist protected helpers ────────────────────────────────────
//
//template <class t>
//void doublylinkedlist<t>::deletelist()
//{
//    node<t>* current = first;
//    while (current != nullptr)
//    {
//        node<t>* nextnode = current->next;
//        delete current;
//        current = nextnode;
//    }
//    first = nullptr;
//    last  = nullptr;
//}
//
//template <class t>
//void doublylinkedlist<t>::copylist(const doublylinkedlist<t>& src)
//{
//    first = nullptr;
//    last  = nullptr;
//    node<t>* current = src.first;
//    while (current != nullptr)
//    {
//        // manually create and link nodes (cannot call virtual insertatlast
//        // from base class constructor — vtable not ready yet)
//        node<t>* newnode    = new node<t>();
//        newnode->data       = current->data;
//        newnode->next       = nullptr;
//        newnode->previous   = last;
//
//        if (last == nullptr)
//            first = newnode;
//        else
//            last->next = newnode;
//
//        last    = newnode;
//        current = current->next;
//    }
//}
//
//
//template <class t>
//class concretedoublylinkedlist :public doublylinkedlist<t>
//{
//public:
//    concretedoublylinkedlist() : doublylinkedlist<t>() {}
//    concretedoublylinkedlist(const concretedoublylinkedlist<t>& mll) : doublylinkedlist<t>(mll) {}
//    const concretedoublylinkedlist& operator = (const concretedoublylinkedlist<t>& mll);
//    void insertatlast(t);
//    void insertatfirst(t);
//    void display();
//    t removefromfirst();
//    t removefromlast();
//    bool isempty();
//};
//
//template <class t>
//const concretedoublylinkedlist<t>& concretedoublylinkedlist<t>::operator = (const concretedoublylinkedlist<t>& dll)
//{
//    if (this != &dll)
//    {
//        doublylinkedlist<t>::operator=(dll);
//    }
//    return *this;
//}
//
//
//// ─── concretedoublylinkedlist implementations ──────────────────────────────
//
//template <class t>
//bool concretedoublylinkedlist<t>::isempty()
//{
//    return (doublylinkedlist<t>::first == nullptr);
//}
//
//template <class t>
//void concretedoublylinkedlist<t>::insertatfirst(t value)
//{
//    node<t>* newnode    = new node<t>();
//    newnode->data       = value;
//    newnode->next       = doublylinkedlist<t>::first;
//    newnode->previous   = nullptr;
//
//    if (isempty())
//    {
//        doublylinkedlist<t>::last = newnode;
//    }
//    else
//    {
//        doublylinkedlist<t>::first->previous = newnode;
//    }
//    doublylinkedlist<t>::first = newnode;
//}
//
//template <class t>
//void concretedoublylinkedlist<t>::insertatlast(t value)
//{
//    node<t>* newnode    = new node<t>();
//    newnode->data       = value;
//    newnode->next       = nullptr;
//    newnode->previous   = doublylinkedlist<t>::last;
//
//    if (isempty())
//    {
//        doublylinkedlist<t>::first = newnode;
//    }
//    else
//    {
//        doublylinkedlist<t>::last->next = newnode;
//    }
//    doublylinkedlist<t>::last = newnode;
//}
//
//template <class t>
//t concretedoublylinkedlist<t>::removefromfirst()
//{
//    if (isempty())
//    {
//        cout << "list is empty! cannot remove from first." << endl;
//        return t();
//    }
//    node<t>* todelete = doublylinkedlist<t>::first;
//    t value           = todelete->data;
//
//    doublylinkedlist<t>::first = todelete->next;
//
//    if (doublylinkedlist<t>::first == nullptr)
//    {
//        doublylinkedlist<t>::last = nullptr;   // list is now empty
//    }
//    else
//    {
//        doublylinkedlist<t>::first->previous = nullptr;
//    }
//    delete todelete;
//    return value;
//}
//
//template <class t>
//t concretedoublylinkedlist<t>::removefromlast()
//{
//    if (isempty())
//    {
//        cout << "list is empty! cannot remove from last." << endl;
//        return t();
//    }
//    node<t>* todelete = doublylinkedlist<t>::last;
//    t value           = todelete->data;
//
//    doublylinkedlist<t>::last = todelete->previous;
//
//    if (doublylinkedlist<t>::last == nullptr)
//    {
//        doublylinkedlist<t>::first = nullptr;  // list is now empty
//    }
//    else
//    {
//        doublylinkedlist<t>::last->next = nullptr;
//    }
//    delete todelete;
//    return value;
//}
//
//template <class t>
//void concretedoublylinkedlist<t>::display()
//{
//    if (isempty())
//    {
//        cout << "[ empty list ]" << endl;
//        return;
//    }
//    node<t>* current = doublylinkedlist<t>::first;
//    cout << "nullptr <- ";
//    while (current != nullptr)
//    {
//        cout << "[" << current->data << "]";
//        if (current->next != nullptr) cout << " <-> ";
//        current = current->next;
//    }
//    cout << " -> nullptr" << endl;
//}
//
//// ─── main ───────────────────────────────────────────────────────────────────
//
//int main()
//{
//    cout << "=== task 1: doublylinkedlist demo ===" << endl << endl;
//
//    concretedoublylinkedlist<int> dll;
//
//    cout << "-- insertatlast: 10, 20, 30 --" << endl;
//    dll.insertatlast(10);
//    dll.insertatlast(20);
//    dll.insertatlast(30);
//    dll.display();
//
//    cout << "\n-- insertatfirst: 5 --" << endl;
//    dll.insertatfirst(5);
//    dll.display();
//
//    cout << "\n-- removefromfirst (expected 5): " << dll.removefromfirst() << endl;
//    dll.display();
//
//    cout << "\n-- removefromlast (expected 30): " << dll.removefromlast() << endl;
//    dll.display();
//
//    cout << "\n-- copy constructor test --" << endl;
//    concretedoublylinkedlist<int> copy(dll);
//    cout << "original: "; dll.display();
//    cout << "copy:     "; copy.display();
//
//    cout << "\n-- assignment operator test --" << endl;
//    concretedoublylinkedlist<int> assigned;
//    assigned = dll;
//    cout << "assigned: "; assigned.display();
//
//    cout << "\n-- isempty on empty list --" << endl;
//    concretedoublylinkedlist<int> empty;
//    cout << "isempty: " << (empty.isempty() ? "true" : "false") << endl;
//
//    cout << "\n-- remove from empty list (error check) --" << endl;
//    empty.removefromfirst();
//
//    cout << "\ndone." << endl;
//    return 0;
//}
