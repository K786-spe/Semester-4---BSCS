//
//
//#include <iostream>
//using namespace std;
//
//#include "AbstractStack.h"
//#include "ArrayStack.h"
//
//// ─── copyStack: recursive ──────────────────────────────────────────────────
//// Base case: src is empty → stop
//// Recursive: pop from src, recurse, then push to copy
//// Using call stack reversal so copy ends up in same order as source
//void copyStack(ArrayStack<int> src, ArrayStack<int>& copy)
//{
//    if (src.isEmpty()) return;   // base case
//
//    int v = 0;
//    src.pop(v);                  // remove top from source
//
//    copyStack(src, copy);        // recurse on smaller stack
//
//    copy.push(v);                // push AFTER recursion → preserves order
//}
//
//// ─── display: recursive ────────────────────────────────────────────────────
//// Base case: stack is empty → return
//// Recursive: pop value, recurse, then print value (prints bottom-to-top)
//void display(ArrayStack<int> as)
//{
//    if (as.isEmpty()) return;    // base case
//
//    int v = 0;
//    as.pop(v);                   // remove top
//
//    display(as);                 // recurse first (goes deep to bottom)
//
//    cout << v << " ";            // print on the way BACK (bottom to top order)
//}
//
//// ─── getSize: recursive ────────────────────────────────────────────────────
//// Base case: stack is empty → return 0
//// Recursive: pop one, return 1 + getSize(rest)
//int getSize(ArrayStack<int> as)
//{
//    if (as.isEmpty()) return 0;  // base case
//
//    int v = 0;
//    as.pop(v);                   // remove one element
//
//    return 1 + getSize(as);      // count it + count the rest
//}
//
//// ─── max: recursive ─────────────────────────────────────────────────────────
//// Base case: only 1 element left → pop and return it
//// Recursive: pop top, get max of rest, return larger
//int maxStack(ArrayStack<int> as)
//{
//    int v = 0;
//    as.pop(v);                   // pop current top
//
//    if (as.isEmpty()) return v;  // base case: this was the only element
//
//    int restMax = maxStack(as);  // get max of remaining elements
//
//    return (v > restMax) ? v : restMax;
//}
//
//// ─── helper: fill a stack ──────────────────────────────────────────────────
//ArrayStack<int> makeStack(int vals[], int n, int capacity)
//{
//    ArrayStack<int> s(capacity);
//    for (int i = 0; i < n; i++) s.push(vals[i]);
//    return s;
//}
//
//// ─── main ────────────────────────────────────────────────────────────────────
//int main()
//{
//    cout << "=== Task 3: Recursive ArrayStack Functions ===" << endl << endl;
//
//    int data[] = {5, 3, 8, 1, 7};
//    ArrayStack<int> original = makeStack(data, 5, 10);
//
//    cout << "Original stack (bottom to top): ";
//    display(original);
//    cout << endl;
//
//    cout << "\n-- getSize: " << getSize(original) << " (expected 5) --" << endl;
//
//    cout << "-- maxStack: " << maxStack(original) << " (expected 8) --" << endl;
//
//    cout << "\n-- copyStack test --" << endl;
//    ArrayStack<int> copy(10);
//    copyStack(original, copy);
//    cout << "Copy (bottom to top): ";
//    display(copy);
//    cout << endl;
//
//    cout << "\n-- Single element stack max --" << endl;
//    int single[] = {42};
//    ArrayStack<int> s1 = makeStack(single, 1, 5);
//    cout << "maxStack([42]): " << maxStack(s1) << " (expected 42)" << endl;
//
//    cout << "\n-- getSize on empty stack --" << endl;
//    ArrayStack<int> empty(5);
//    cout << "getSize(empty): " << getSize(empty) << " (expected 0)" << endl;
//
//    cout << "\nDone." << endl;
//    return 0;
//}
