#include <iostream>
using namespace std;

#include "node.h"
#include "doublylinkedlist.h"
#include "concretedoublylinkedlist.h"

// ─── llcopy: recursive ───────────────────────────────────────────────
void llcopy(ConcreteDoublyLinkedList<int> src, ConcreteDoublyLinkedList<int>& copy)
{
    if (src.isEmpty()) return;

    int x = src.removeFromLast();
    copy.insertAtFirst(x);

    llcopy(src, copy);
}

// ─── display: recursive ──────────────────────────────────────────────
void display(ConcreteDoublyLinkedList<int> as)
{
    if (as.isEmpty()) {
        cout << endl;
        return;
    }

    int v = as.removeFromFirst();
    cout << v << " -> ";
    display(as);
}

// ─── getsize: recursive ──────────────────────────────────────────────
int getsize(ConcreteDoublyLinkedList<int> as)
{
    if (as.isEmpty()) return 0;

    as.removeFromLast();
    return 1 + getsize(as);
}

// ─── max: recursive without INT_MIN ──────────────────────────────────
int maxll(ConcreteDoublyLinkedList<int> as)
{
    int current = as.removeFromLast();

    if (as.isEmpty()) {
        // base case: only one element
        return current;
    }

    int restmax = maxll(as);
    return (current > restmax) ? current : restmax;
}

// ─── helper: build a list ────────────────────────────────────────────
ConcreteDoublyLinkedList<int> makelist(int vals[], int n)
{
    ConcreteDoublyLinkedList<int> dll;
    for (int i = 0; i < n; i++) dll.insertAtLast(vals[i]);
    return dll;
}

// ── main ─────────────────────────────────────────────────────────────
int main()
{
    cout << "=== task 5: recursive doublylinkedlist functions ===" << endl << endl;

    int data[] = { 10, 40, 20, 70, 30 };
    ConcreteDoublyLinkedList<int> original = makelist(data, 5);

    cout << "original list: ";
    display(original);

    cout << "\n-- getsize: " << getsize(original) << " (expected 5) --" << endl;
    cout << "-- maxll: " << maxll(original) << " (expected 70) --" << endl;

    cout << "\n-- llcopy test --" << endl;
    ConcreteDoublyLinkedList<int> copy;
    llcopy(original, copy);
    cout << "copy: ";
    display(copy);

    cout << "\n-- single element list --" << endl;
    int single[] = { 42 };
    ConcreteDoublyLinkedList<int> s1 = makelist(single, 1);
    cout << "maxll([42]): " << maxll(s1) << " (expected 42)" << endl;

    cout << "\n-- getsize on empty list --" << endl;
    ConcreteDoublyLinkedList<int> empty;
    cout << "getsize(empty): " << getsize(empty) << " (expected 0)" << endl;

    cout << "\ndone." << endl;
    return 0;
}
