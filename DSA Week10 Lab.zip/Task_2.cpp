//
//#include <iostream>
//using namespace std;
//
//// ─── 1. func: count down from n to 1 ────────────────────────────────────────
//// Base case:  n <= 0  → stop (nothing to print)
//// Recursive:  print n, then solve for n-1
//void func(int n)
//{
//    if (n <= 0) return;          // base case
//    cout << n << endl;
//    func(n - 1);                 // recursive call with smaller n
//}
//
//// ─── 2. sum: 1+2+...+n ──────────────────────────────────────────────────────
//// Base case:  n <= 0  → return 0
//// Recursive:  n + sum(n-1)
//int sum(int n)
//{
//    if (n <= 0) return 0;        // base case
//    return n + sum(n - 1);       // recursive call
//}
//
//// ─── 3. max: find maximum in array ──────────────────────────────────────────
//// Base case:  size == 1  → return a[0]  (single element is the max)
//// Recursive:  compare last element with max of the rest
//int maxArr(int a[], int size)
//{
//    if (size == 1) return a[0];  // base case
//
//    int restMax = maxArr(a, size - 1);
//    return (a[size - 1] > restMax) ? a[size - 1] : restMax;
//}
//
//// ─── 4. countDigits: count non-zero digits ───────────────────────────────────
//// Base case:  n <= 0  → return 0
//// Recursive:  count current digit + countDigits(n/10)
//int countDigits(int n)
//{
//    if (n <= 0) return 0;        // base case
//
//    int current = (n % 10 != 0) ? 1 : 0;
//    return current + countDigits(n / 10);
//}
//
//// ─── 5. displayDigits: print digits from right to left ────────────────────
//// Base case:  n <= 0  → print newline and return
//// Recursive:  print last digit, then recurse with n/10
//void displayDigits(int n)
//{
//    if (n <= 0)
//    {
//        cout << endl;
//        return;
//    }
//    cout << n % 10 << " ";
//    displayDigits(n / 10);       // recursive call
//}
//
//// ─── 6. binarySearch ────────────────────────────────────────────────────────
//// Base case:  low > high  → return -1 (not found)
//// Recursive:  calculate mid; if found return mid; else narrow the range
//int binarySearch(int a[], int low, int high, int v)
//{
//    if (low > high) return -1;   // base case: range exhausted
//
//    int mid = (low + high) / 2;
//
//    if (a[mid] == v)   return mid;
//    if (v > a[mid])    return binarySearch(a, mid + 1, high, v);   // search right
//    return                    binarySearch(a, low, mid - 1, v);    // search left
//}
//
//// ─── main ────────────────────────────────────────────────────────────────────
//int main()
//{
//    cout << "=== Task 2: Recursive Functions Demo ===" << endl << endl;
//
//    // Test func
//    cout << "-- func(5): count down --" << endl;
//    func(5);
//
//    // Test sum
//    cout << "\n-- sum(10): " << sum(10) << " (expected 55) --" << endl;
//
//    // Test maxArr
//    int arr[] = {3, 7, 1, 9, 4};
//    cout << "\n-- maxArr([3,7,1,9,4]): " << maxArr(arr, 5) << " (expected 9) --" << endl;
//
//    // Test countDigits
//    cout << "\n-- countDigits(10305): " << countDigits(10305)
//         << " (expected 3, zeros excluded) --" << endl;
//    cout << "-- countDigits(12345): " << countDigits(12345)
//         << " (expected 5) --" << endl;
//
//    // Test displayDigits
//    cout << "\n-- displayDigits(1234): ";
//    displayDigits(1234);
//
//    // Test binarySearch
//    int sorted[] = {1, 3, 5, 7, 9, 11, 13};
//    int idx = binarySearch(sorted, 0, 6, 7);
//    cout << "\n-- binarySearch([1,3,5,7,9,11,13], find 7): index = "
//         << idx << " (expected 3) --" << endl;
//
//    idx = binarySearch(sorted, 0, 6, 6);
//    cout << "-- binarySearch([1,3,5,7,9,11,13], find 6): index = "
//         << idx << " (expected -1) --" << endl;
//
//    cout << "\nDone." << endl;
//    return 0;
//}
