#include <iostream>
using namespace std;

class Node {

public:
    int data;
    Node* left;
    Node* right;

    
    Node(int value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};


class BST {

private:
    Node* root;

public:

    BST() {
        root = NULL;
    }

    Node* insert(Node* temp, int value) {

        if (temp == NULL) {
            return new Node(value);
        }

        if (value < temp->data) {
            temp->left = insert(temp->left, value);
        }

        else if (value > temp->data) {
            temp->right = insert(temp->right, value);
        }

        return temp;
    }

    void insertValue(int value) {
        root = insert(root, value);
    }

    
    void inorder(Node* temp) {

        if (temp == NULL)
            return;

        inorder(temp->left);

        cout << temp->data << " ";

        inorder(temp->right);
    }

    
    void display() {

        cout << "BST Elements in Ascending Order:\n";

        inorder(root);

        cout << endl;
    }
};

int main() {

    BST tree;

    
    tree.insertValue(50);
    tree.insertValue(30);
    tree.insertValue(70);
    tree.insertValue(20);
    tree.insertValue(40);
    tree.insertValue(60);
    tree.insertValue(80);

    
    tree.display();

    return 0;
}