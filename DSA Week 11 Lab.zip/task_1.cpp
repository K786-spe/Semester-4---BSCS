#include<iostream>
using namespace std;


class node {
public:
	int data;
	node* left;
	node* right;

	node(int value) {
		data = value;
		left = NULL;
		right = NULL;
	}
};

class binaryTree {
	node* root;
public:
	binaryTree() {
		root = NULL;
	}
	void createTree() {
		root = new node(1);

		root->left = new node(2);
		root->right = new node(3);

		root->left->left = new node(4);
		root->left->right = new node(5);
	}
	void inorder(node* temp) {
		if (temp == NULL)return;
		inorder(temp->left);
		cout << temp->data << " ";
		inorder(temp->right);
	}
	void preorder(node* temp) {
		if (temp == NULL)return;
		cout << temp->data << " ";
		preorder(temp->left);
		preorder(temp->right);
	}
	void postorder(node* temp) {

		if (temp == NULL)
			return;

		postorder(temp->left);
		postorder(temp->right);
		cout << temp->data << " ";
	}

	void displayInorder() {
		cout << "In-order Traversal: ";
		inorder(root);
		cout << endl;
	}

	void displayPreorder() {
		cout << "Pre-order Traversal: ";
		preorder(root);
		cout << endl;
	}

	void displayPostorder() {
		cout << "Post-order Traversal: ";
		postorder(root);
		cout << endl;
	}
};

int main() {

	binaryTree tree;

	tree.createTree();

	tree.displayInorder();

	tree.displayPreorder();

	tree.displayPostorder();

	return 0;
}