#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};

class BST {
private:
    Node* root;

public:
    BST() {
        root = NULL;
    }


    Node* insert(Node* temp, int value) {

        if (temp == NULL)
            return new Node(value);

        if (value < temp->data)
            temp->left = insert(temp->left, value);
        else if (value > temp->data)
            temp->right = insert(temp->right, value);

        return temp;
    }

    void insertValue(int value) {
        root = insert(root, value);
    }

    
    void inorder(Node* temp) {

        if (temp == NULL)
            return;

        inorder(temp->left);
        cout << temp->data << " ";
        inorder(temp->right);
    }

    void display() {
        cout << "In-order Traversal: ";
        inorder(root);
        cout << endl;
    }

    // Find minimum in right subtree (used in deletion)
    Node* findMin(Node* temp) {
        while (temp->left != NULL)
            temp = temp->left;
        return temp;
    }

    Node* deleteNode(Node* temp, int value) {

        if (temp == NULL)
            return NULL;

       
        if (value < temp->data) {
            temp->left = deleteNode(temp->left, value);
        }

        
        else if (value > temp->data) {
            temp->right = deleteNode(temp->right, value);
        }

        else {

            if (temp->left == NULL && temp->right == NULL) {
                delete temp;
                return NULL;
            }

            else if (temp->left == NULL) {
                Node* tempNode = temp->right;
                delete temp;
                return tempNode;
            }

            
            else if (temp->right == NULL) {
                Node* tempNode = temp->left;
                delete temp;
                return tempNode;
            }

          
            else {
                Node* successor = findMin(temp->right);
                temp->data = successor->data;
                temp->right = deleteNode(temp->right, successor->data);
            }
        }

        return temp;
    }

    void deleteValue(int value) {
        root = deleteNode(root, value);
    }
};

int main() {

    BST tree;

    // Insert values
    tree.insertValue(50);
    tree.insertValue(30);
    tree.insertValue(70);
    tree.insertValue(20);
    tree.insertValue(40);
    tree.insertValue(60);
    tree.insertValue(80);

    cout << "Original BST:\n";
    tree.display();

    int key;
    cout << "\nEnter value to delete: ";
    cin >> key;

    tree.deleteValue(key);

    cout << "\nBST after deletion:\n";
    tree.display();

    return 0;
}
