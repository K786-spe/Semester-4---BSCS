#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};

class BST {
private:
    Node* root;

public:
    BST() {
        root = NULL;
    }

    // Insert recursively
    Node* insert(Node* temp, int value) {

        if (temp == NULL)
            return new Node(value);

        if (value < temp->data)
            temp->left = insert(temp->left, value);
        else if (value > temp->data)
            temp->right = insert(temp->right, value);

        return temp;
    }

    void insertValue(int value) {
        root = insert(root, value);
    }

    // Recursive minimum (leftmost node)
    int findMin(Node* temp) {

        if (temp == NULL) {
            cout << "Tree is empty.\n";
            return -1;
        }

        if (temp->left == NULL)
            return temp->data;

        return findMin(temp->left);
    }

    // Recursive maximum (rightmost node)
    int findMax(Node* temp) {

        if (temp == NULL) {
            cout << "Tree is empty.\n";
            return -1;
        }

        if (temp->right == NULL)
            return temp->data;

        return findMax(temp->right);
    }

    // Wrapper functions
    int getMin() {
        return findMin(root);
    }

    int getMax() {
        return findMax(root);
    }
};

int main() {

    BST tree;

    // Insert values
    tree.insertValue(50);
    tree.insertValue(30);
    tree.insertValue(70);
    tree.insertValue(20);
    tree.insertValue(40);
    tree.insertValue(60);
    tree.insertValue(80);

    cout << "Minimum value in BST: " << tree.getMin() << endl;
    cout << "Maximum value in BST: " << tree.getMax() << endl;

    return 0;
}