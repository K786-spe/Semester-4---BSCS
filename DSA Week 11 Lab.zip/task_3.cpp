#include <iostream>
using namespace std;

// Node class
class Node {

public:
    int data;
    Node* left;
    Node* right;

    // Constructor
    Node(int value) {
        data = value;
        left = NULL;
        right = NULL;
    }
};

class BST {

private:
    Node* root;

public:

    BST() {
        root = NULL;
    }

    Node* insert(Node* temp, int value) {

        if (temp == NULL) {
            return new Node(value);
        }

        if (value < temp->data) {
            temp->left = insert(temp->left, value);
        }

        else if (value > temp->data) {
            temp->right = insert(temp->right, value);
        }

        return temp;
    }

    void insertValue(int value) {
        root = insert(root, value);
    }

    void inorder(Node* temp) {

        if (temp == NULL)
            return;

        inorder(temp->left);

        cout << temp->data << " ";

        inorder(temp->right);
    }

    void display() {

        cout << "BST Elements in Ascending Order:\n";

        inorder(root);

        cout << endl;
    }

    bool search(Node* temp, int value) {

        if (temp == NULL)
            return false;

        if (temp->data == value)
            return true;

        if (value < temp->data) {
            return search(temp->left, value);
        }

        else {
            return search(temp->right, value);
        }
    }

    bool searchValue(int value) {
        return search(root, value);
    }
};

int main() {

    BST tree;

    tree.insertValue(50);
    tree.insertValue(30);
    tree.insertValue(70);
    tree.insertValue(20);
    tree.insertValue(40);
    tree.insertValue(60);
    tree.insertValue(80);

    tree.display();

    int key;

    cout << "\nEnter value to search: ";
    cin >> key;

    if (tree.searchValue(key)) {
        cout << key << " found in BST." << endl;
    }
    else {
        cout << key << " not found in BST." << endl;
    }

    return 0;
}