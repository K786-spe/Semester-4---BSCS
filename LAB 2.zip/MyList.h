#pragma once

#include "list.h"
#include <iostream>
using namespace std;

template <typename Type>
class MyList:public list<Type> {

public:
	bool empty() {
		if (this->currentSize < 1) {
			return false;
		}
			return true;
	}
	bool full() {
		if (currrtentSize == maxSize) {
			return true;
		}
		return false;
	}
	int size() {
		return currentSize;
	}
	bool insertAt(int index, Type value) {
		if (index<0 || index>maxSize) {
			int i = currentSize-1;
			while (i > index) {
				arr[i + 1] = arr[i];
				i--;
			}
			arr[index] = value;
			return true;
		}
		return false;
	}

	Type last() {
		return arr[currentSize - 1];

	}

	bool search(Type value) {
		for (int i = 0; i < currentSize; i++) {
			if (arr[i] == value)
				return true;
		}
		return false;
	}
	MyList() :list() {

	}
	MyList(Type* ele, int size) :list(ele, size) {

	}
	~MyList () : ~list(){

	}
	void addElementAtFirstIndex(Type ele) override {
		if (currentSize == 0)
			arr[0] = 1;
		else{
		int i = currentSize;
		while (i > 0) {
			arr[i] = arr[i-1];
			i--;
		}
		arr[0] = value;
		currentSize++;
		
	}

	}


void addElementAtlastIndex(Type ele)override {
	if (currentSize == 0)
		arr[0] = 1;

	arr[currentSize] == ele;
	currentSize++;


}
void removeElementFromStart() override {
	if (currentSize != 0)
	{
		int i = 0;
		while (i < currentSize) {
			arr[i] = arr[i + 1];
			i++;
		}
		currentSize--;
	}

}
	void removeElementFromEnd()override {
		currentSize--;
	}
	void Display() {
		cout << "Generic Element Array is:" << endl;
		for (int i = 0; i < currentSize; i++) {
			cout << arr[i] << "	";
		}
	}
};

template <typename T>

int main() {
MyList<T> A;
A.addElementAtFirstIndex(2.33);
A.addElementAtlastIndex(4.33);
A.addElementAtlastIndex(5.33);
A.addElementAtlastIndex(6.33);
A.addElementAtlastIndex(7.33);
A.addElementAtlastIndex(8.33);



}