#pragma once

template <class T>
class list {
protacted:

	T* arr;
	int maxSize;
	int currentSize;

public:
	list() {
		arr = nullptr;
		maxSize = 0;
		currentSize = 0;
	}
	list(T* arr, int size) {
		T* array = new T[size];
		for (int i = 0; i < size; i++) {
			array[i] = arr[i];
		}
	}
	virtual void addElementAtFirstIndex(T ele) = 0;
	virtual void addElementAtlastIndex(T ele) = 0;
	virtual void removeElementFromStart() = 0;
	virtual void removeElementFromEnd() = 0;
	~list() {
		delete []arr;
	}

 };
