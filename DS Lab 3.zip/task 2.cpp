//#include <iostream>
//#include "myStack.h"
//using namespace std;
//
//int main() {
//    int choice, value;
//    myStack<int> s(5);  // stack of size 5
//
//    do {
//        cout << "\n--- Stack Menu ---\n";
//        cout << "1. Push element\n";
//        cout << "2. Pop element\n";
//        cout << "3. Show top element\n";
//        cout << "4. Check if stack is empty\n";
//        cout << "5. Check if stack is full\n";
//        cout << "6. Display stack elements\n";
//        cout << "7. Show minimum element\n";
//        cout << "8. Exit\n";
//        cout << "Enter choice: ";
//        cin >> choice;
//
//        switch (choice) {
//        case 1:
//            cout << "Enter value: ";
//            cin >> value;
//            s.push(value);
//            break;
//        case 2:
//            try {
//                cout << "Popped: " << s.pop() << endl;
//            }
//            catch (exception& e) {
//                cout << e.what() << endl;
//            }
//            break;
//        case 3:
//            try {
//                cout << "Top element: " << s.top() << endl;
//            }
//            catch (exception& e) {
//                cout << e.what() << endl;
//            }
//            break;
//        case 4:
//            cout << (s.isEmpty() ? "Stack is empty" : "Stack is not empty") << endl;
//            break;
//        case 5:
//            cout << (s.isFull() ? "Stack is full" : "Stack is not full") << endl;
//            break;
//        case 6:
//            s.display();
//            break;
//        case 7:
//            try {
//                cout << "Minimum element: " << s.getMin() << endl;
//            }
//            catch (exception& e) {
//                cout << e.what() << endl;
//            }
//            break;
//        case 8:
//            cout << "Exiting..." << endl;
//            break;
//        default:
//            cout << "Invalid choice!" << endl;
//        }
//    } while (choice != 8);
//
//    return 0;
//}
