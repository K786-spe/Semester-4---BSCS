//#include <iostream>
//using namespace std;
//
//class myCarStack {
//    int* A;       
//    int top;      
//    int limit;    
//
//public:
//    myCarStack(int size = 8) {
//        limit = size;
//        A = new int[limit];
//        top = -1;
//    }
//
//    ~myCarStack() {
//        delete[] A;
//    }
//
//    bool isFull() const {
//        return top + 1 == limit;
//    }
//
//    bool isEmpty() const {
//        return top == -1;
//    }
//
//    void push(int number) {
//        if (!isFull()) {
//            A[++top] = number;
//            cout << "Car " << number << " parked at position " << top << endl;
//        }
//        else {
//            cout << "Parking lot is full!" << endl;
//        }
//    }
//
//    int pop() {
//        if (!isEmpty()) {
//            return A[top--];
//        }
//        else {
//            throw underflow_error("Parking lot is empty!");
//        }
//    }
//
//    int peek() const {
//        if (!isEmpty()) {
//            return A[top];
//        }
//        else {
//            throw underflow_error("Parking lot is empty!");
//        }
//    }
//
//    int size() const {
//        return top + 1;
//    }
//
//    bool search(int number) const {
//        for (int i = 0; i <= top; i++) {
//            if (A[i] == number) return true;
//        }
//        return false;
//    }
//
//    void display() const {
//        if (isEmpty()) {
//            cout << "Parking lot is empty!" << endl;
//        }
//        else {
//            cout << "Cars in parking lot (front to back): ";
//            for (int i = 0; i <= top; i++) {
//                cout << A[i] << " ";
//            }
//            cout << endl;
//        }
//    }
//
//    void removeCar(int number) {
//        if (!search(number)) {
//            cout << "Car " << number << " not found in parking lot!" << endl;
//            return;
//        }
//
//        myCarStack temp(limit); 
//
//        while (!isEmpty() && peek() != number) {
//            temp.push(pop());
//        }
//
//        if (!isEmpty() && peek() == number) {
//            cout << "Car " << pop() << " has left the parking lot." << endl;
//        }
//
//        while (!temp.isEmpty()) {
//            push(temp.pop());
//        }
//    }
//};
//
//
//
//int main() {
//    myCarStack parkingLot(8);
//    int choice, carNumber;
//
//    do {
//        cout << "\n--- Parking Lot Menu ---\n";
//        cout << "1. Park a new car\n";
//        cout << "2. Remove a car by number\n";
//        cout << "3. Show car currently at exit (top)\n";
//        cout << "4. Show total cars parked\n";
//        cout << "5. Search for a car\n";
//        cout << "6. Display all cars\n";
//        cout << "7. Exit\n";
//        cout << "Enter choice: ";
//        cin >> choice;
//
//        switch (choice) {
//        case 1:
//            cout << "Enter car number: ";
//            cin >> carNumber;
//            parkingLot.push(carNumber);
//            break;
//        case 2:
//            cout << "Enter car number to remove: ";
//            cin >> carNumber;
//            parkingLot.removeCar(carNumber);
//            break;
//        case 3:
//            try {
//                cout << "Car at exit: " << parkingLot.peek() << endl;
//            }
//            catch (exception& e) {
//                cout << e.what() << endl;
//            }
//            break;
//        case 4:
//            cout << "Total cars parked: " << parkingLot.size() << endl;
//            break;
//        case 5:
//            cout << "Enter car number to search: ";
//            cin >> carNumber;
//            cout << (parkingLot.search(carNumber) ? "Car is present." : "Car not found.") << endl;
//            break;
//        case 6:
//            parkingLot.display();
//            break;
//        case 7:
//            cout << "Exiting..." << endl;
//            break;
//        default:
//            cout << "Invalid choice!" << endl;
//        }
//    } while (choice != 7);
//
//    return 0;
//}
