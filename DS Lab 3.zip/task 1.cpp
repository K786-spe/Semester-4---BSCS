//#include <iostream>
//#include "myStack.h"
//using namespace std;
//
//int main() {
//    int choice, value;
//    myStack<int> s(5);  // stack of size 5
//
//    do {
//        cout << "\n--- Stack Menu ---\n";
//        cout << "1. Push\n";
//        cout << "2. Pop\n";
//        cout << "3. Top\n";
//        cout << "4. Display\n";
//        cout << "5. Exit\n";
//        cout << "Enter choice: ";
//        cin >> choice;
//
//        switch (choice) {
//        case 1:
//            cout << "Enter value: ";
//            cin >> value;
//            s.push(value);
//            break;
//        case 2:
//            try {
//                cout << "Popped: " << s.pop() << endl;
//            }
//            catch (exception& e) {
//                cout << e.what() << endl;
//            }
//            break;
//        case 3:
//            try {
//                cout << "Top element: " << s.top() << endl;
//            }
//            catch (exception& e) {
//                cout << e.what() << endl;
//            }
//            break;
//        case 4:
//            s.display();
//            break;
//        case 5:
//            cout << "Exiting..." << endl;
//            break;
//        default:
//            cout << "Invalid choice!" << endl;
//        }
//    } while (choice != 5);
//
//    return 0;
//}
