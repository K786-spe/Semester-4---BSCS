#include <iostream>
#include <stack>
#include <string>
using namespace std;

class TextEditor {
private:
    string text;                 // current text
    stack<string> undoStack;     // stack for undo
    stack<string> redoStack;     // stack for redo

public:
    void insertChar(char c) {
        text.push_back(c);
        undoStack.push("insert:" + string(1, c));
        while (!redoStack.empty()) redoStack.pop(); // clear redo history
    }

    void deleteChar() {
        if (!text.empty()) {
            char c = text.back();
            text.pop_back();
            undoStack.push("delete:" + string(1, c));
            while (!redoStack.empty()) redoStack.pop();
        }
        else {
            cout << "Nothing to delete!" << endl;
        }
    }

    void undo() {
        if (undoStack.empty()) {
            cout << "Nothing to undo!" << endl;
            return;
        }

        string last = undoStack.top();
        undoStack.pop();

        if (last.find("insert:") == 0) {
            char c = last[7]; // after "insert:"
            text.pop_back();
            redoStack.push(last);
        }
        else if (last.find("delete:") == 0) {
            char c = last[7]; // after "delete:"
            text.push_back(c);
            redoStack.push(last);
        }
    }

    void redo() {
        if (redoStack.empty()) {
            cout << "Nothing to redo!" << endl;
            return;
        }

        string last = redoStack.top();
        redoStack.pop();

        if (last.find("insert:") == 0) {
            char c = last[7];
            text.push_back(c);
            undoStack.push(last);
        }
        else if (last.find("delete:") == 0) {
            char c = last[7];
            text.pop_back();
            undoStack.push(last);
        }
    }

    void showText() const {
        cout << "Current text: \"" << text << "\"" << endl;
    }
};



int main() {
    TextEditor editor;
    int choice;
    char c;

    do {
        cout << "\n--- Text Editor Menu ---\n";
        cout << "1. Insert character\n";
        cout << "2. Delete character\n";
        cout << "3. Undo\n";
        cout << "4. Redo\n";
        cout << "5. Show text\n";
        cout << "6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter character: ";
            cin >> c;
            editor.insertChar(c);
            break;
        case 2:
            editor.deleteChar();
            break;
        case 3:
            editor.undo();
            break;
        case 4:
            editor.redo();
            break;
        case 5:
            editor.showText();
            break;
        case 6:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
        }
    } while (choice != 6);

    return 0;
}
