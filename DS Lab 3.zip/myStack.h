#pragma once
#include <iostream>
#include "AbstractStack.h"
using namespace std;

template <class T>
class myStack : public AbstractStack<T> {
private:
    T* A;          // main stack
    T* minStack;   // auxiliary stack for minimums
    int maxSize;
    int topIndex;
    int minTop;

public:
    myStack(int size = 10) {
        maxSize = size;
        A = new T[maxSize];
        minStack = new T[maxSize];
        topIndex = -1;
        minTop = -1;
    }

    ~myStack() {
        delete[] A;
        delete[] minStack;
    }

    void push(T value) override {
        if (!isFull()) {
            A[++topIndex] = value;

            // maintain min stack
            if (minTop == -1 || value <= minStack[minTop]) {
                minStack[++minTop] = value;
            }

            cout << value << " pushed at index " << topIndex << endl;
        }
        else {
            cout << "Stack is full!" << endl;
        }
    }

    T pop() override {
        if (!isEmpty()) {
            T popped = A[topIndex--];

            // maintain min stack
            if (popped == minStack[minTop]) {
                minTop--;
            }

            cout << popped << " popped" << endl;
            return popped;
        }
        else {
            throw underflow_error("Stack is empty!");
        }
    }

    T top() const override {
        if (!isEmpty()) {
            return A[topIndex];
        }
        else {
            throw underflow_error("Stack is empty!");
        }
    }

    T getMin() const override {
        if (minTop != -1) {
            return minStack[minTop];
        }
        else {
            throw underflow_error("Stack is empty!");
        }
    }

    bool isEmpty() const override {
        return topIndex == -1;
    }

    bool isFull() const override {
        return topIndex == maxSize - 1;
    }

    void display() const {
        if (isEmpty()) {
            cout << "Stack is empty!" << endl;
        }
        else {
            cout << "Stack elements (top to bottom): ";
            for (int i = topIndex; i >= 0; --i) {
                cout << A[i] << " ";
            }
            cout << endl;
        }
    }
};
